from Crypto.Random import get_random_bytes
import random

def crypt(plaintext):
    rnd = random.sample(range(len(plaintext)),k=1)[0]
    rand = get_random_bytes(len(plaintext))
    val = rand[rnd] | plaintext[rnd]
    return rand[:rnd] + val.to_bytes(1,'big') + rand[(rnd+1):]

ciphertexts = []

FLAG = "ISMCTF{fak3_fl4g}"
for i in range(100000):
    ciphertexts.append(crypt(FLAG.encode()).hex())

with open("output.txt", "w") as f:
    for e in ciphertexts:
        f.write(e + '\n')
