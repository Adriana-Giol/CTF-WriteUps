#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef _WIN32
#include <windows.h>
#else
#include <sys/ptrace.h>
#endif

void nothing(double x) {
	int nimic = 0;
	return;
}

void nothing2(double y) {
	int nimic = 0;
	return;
}

void c4n0070b741nM3(int rop) {
	int o_9d4af58ad69040e35fef3ea234c8dd8a[] = {
	111,182,390, 512, 71, 16, 246,6, 146,6, 166,6, 154, 71, 134, 12, 168, 88, 140, 88, 190, 121, 170,56, 190, 37,
	164, 13, 102, 37, 190, 73, 104, 77, 190, 66, 152, 111, 98, 222, 110, 9, 110, 5, 152, 1,
	102, 13, 190, 37, 132, 88, 98, 0, 168, 3, 190, 199, 134,201, 144, 162, 170, 315, 152, 360,
	96, 61, 250, 63, 0, 99
	};

	if (rop == 16843010) {
#ifdef _WIN32
		system("C:\\Windows\\system32\\cmd.exe");
#else
		system("/bin/sh");
#endif

	}

	printf("That's all folks!");
}
void vuln(char* input) {
	char buffer[10];
	memcpy(buffer, input, 35);
}
void getFlag() {
	char nope[] = "";
}

void getCTFlag() {
	char nopeAgain[] = "";
}

int main() {
	char buff[1000] = "ISMCTFniceTryPadawan:P";
	printf("Oops...\n");
	fgets(buff, 1000, stdin);
	vuln(buff);
	return 0;
}
